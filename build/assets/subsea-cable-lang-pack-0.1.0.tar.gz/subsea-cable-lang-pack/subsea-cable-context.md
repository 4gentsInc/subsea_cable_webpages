# Subsea Cable compact context

Pack 0.1.0; language revision `83a897276b0d50a240530b363101dc64cdc42c30`.
Informative authoring knowledge, not Runtime execution evidence.
For syntax and examples, read SKILL.md and the on-demand modules.

# Mental model

Status: informative authoring summary. Sources: `pack.json` → `module_sources`.

A user states a goal in natural language. An Agent authors a **Voyage Plan**:
explicit dependencies and routing in `.vyg` source. The **Subsea Cable Runtime**
realizes that structure. **Vessel** is its control plane; the live **Cable** is
its data plane. A **Host** performs genuine leaf computation: functions, tools,
APIs, or a worker LLM session. Do not label Vessel alone the complete Runtime.

An orchestrator LLM can design and revise the plan while worker LLMs perform
leaf tasks. Both LLMs may be non-deterministic. The authored structural rules
make dependency, routing, and definition selection explicit; they do not make
LLM judgments correct or deterministic. Keep orchestration in Goals rather than
hiding the entire workflow behind one `$doEverything` operation.

A **Goal** describes structural work. It is not a synchronous scalar function.
A **reduction** is the structural rule in a definition; a **deduction** commits
that rule's application to a particular occurrence. **Touchdown** is grounded
leaf work. A selected named definition and the resulting structure are evidence
of how a leaf became part of the plan, not evidence that its tool result is true.

Unqualified `Name/Arity` references remain revisable until their exact occurrence
is demanded. An Agent or authorized operator authors a new definition and
rebinds the alias. Already committed selections stay fixed. Merely parsing,
storing, or resolving a parent does not select all its child Goal definitions.
A pinned `Name#hashPrefix` stays pinned under the implementation's identity
profile. Keep names, immutable artifacts, occurrences, and attempts distinct.

A source unit declares `root Name/inputArity`; it carries no input. The caller
lays a Cable for a target, sends complete input tuples, and observes Values plus
one `EndOfResult` for each admitted input. Decommission closes admission; drainage
then leads to `EndOfStream`. Terminals are controls, not ordinary user Values.
A completed plan does not by itself establish durable recovery or exactly-once
effects.

Public authoring guides explain observable behavior. Grammar checks recognize
source syntax; they do not certify a Runtime. Select an implementation by its
pinned revision, profiles, supported capabilities, and actual feedback.


# Frequent wrong assumptions

Status: informative authoring summary. Sources: `pack.json` → `module_sources`.

| Tempting interpretation | Actual authoring rule |
|---|---|
| `[A[x], B[y]]` forwards A's result | B receives only `y`; use `[A[x], [r] -> B[r, y]]` to forward it |
| `{A[x], B[x]}` returns two values | Unkeyed parallel work has no outward Value; a keyed join returns one Map |
| A keyed join collects a stream | Each branch must provide exactly one Value; `/0` or `/N` is not silently collected |
| A bare downstream Goal runs once | It runs once per upstream Value; `/0` or an empty `/N` invokes it zero times |
| `Goal(args)` returns a scalar inside another argument | It is eager structural work; expose the dependency as a stage instead |
| `root Task/1` includes input 1 | The `1` is arity; send the actual input tuple separately |
| A parent selects all child definitions | Each unqualified Goal reference is selected at that occurrence's demand |
| Updating an alias repairs executed work | Committed selections stay fixed; author new work for reassessment |
| A stored plan proves a tool ran | Structural provenance and execution evidence answer different questions |
| A reused structure means effects can be skipped | Effect reuse needs separate explicit support and evidence |
| An effect-free selector makes the LLM deterministic | It constrains structural selection; Host/LLM computations retain their own semantics |
| `@retry` establishes retry support | Annotation names are insufficient; use a declared supported policy profile |
| Parser success proves a valid, runnable plan | Arity, multiplicity, signatures, profiles, and execution require further checks |

Do not guess a missing output multiplicity as `/1`, silently take the first
stream Value, or wrap the entire orchestration in an opaque Anchor to work around
a structural validation failure. Read the source rule and actual diagnostic.
Do not promise live queries, crash recovery, hash portability, or exact replay
unless the selected implementation explicitly supports and verifies them.


# Write, validate, execute, observe, revise

Status: informative authoring summary. Sources: `pack.json` → `module_sources`.

1. **Check the environment.** Read `pack.json`; compare its language revision
   with the implementation's declared revision and profiles. Discover actual
   connected tools and their schemas. Do not fabricate MCP operation names.
2. **Define the work.** State the root input tuple, expected Values, completion,
   and genuine Host leaves. Record each leaf's input/output, effects, evidence,
   and failure contract. Put dependencies and choices in Goals.
3. **Author and inspect.** Use the syntax and patterns modules. Explain what
   each stage receives and emits. Check explicit routing, arities, keyed joins,
   multiplicities, recursion exits, and referenced Goals or Host bindings.
4. **Validate.** Use the selected implementation's actual source validator when
   available. Separate syntax diagnostics from structural/semantic diagnostics
   and Host-contract checks. Preserve the input source and structured diagnostics
   the tool actually returns. A parser pass alone establishes only syntax.
5. **Execute only a supported path.** Through the declared implementation surface,
   store/publish the validated source, lay the target, and send the complete input
   tuple. These are conceptual operations, not portable MCP command spellings.
   Read actual Values and `EndOfResult`; decommission when finished and wait for
   `EndOfStream`. Report a draft as a draft when no compatible execution tool exists.
6. **Inspect evidence.** Separate authored intent, selected definitions,
   structural deductions, and Host outcomes. Use only authorized, supported
   observations. A final result does not substitute for live evidence when the
   task requires investigation before completion. Mark unavailable evidence.
7. **Revise from evidence.** Describe what assumption failed. Validate a new
   immutable Goal definition, then use the authorized alias-rebind surface.
   Record old/new identities, the reason, and the evidence used. An alias change
   affects only occurrences not yet committed to a selected definition; concurrent
   demand may already have selected the old definition. Verify observed selections
   instead of assuming every pending-looking occurrence used the new definition.

A useful handoff records source and pack revision, Runtime/Host versions and
profiles, validated source, actual diagnostics, input tuple, retained handle (if
supported), output/terminals, evidence references, and any revision identities.
Do not substitute a reconstructed story for unavailable execution evidence.

## Availability at the target revision

The published MCP demo runs only its bundled primes example with limits 1–100.
It does not execute arbitrary user Voyage Plans or expose a step-by-step trace.
General Plan validation/publication/execution and alias-rebind MCP integration
are not established by this pack. Portable live provenance queries are not an
active public contract at this revision. A separately supported experimental
profile must declare its own scope; a Draft proposal is not activated behavior.

Read the dated [availability report](https://4gentsinc.github.io/subsea_cable_webpages/RUNTIME_STATUS/)
and [demo instructions](https://4gentsinc.github.io/subsea_cable_webpages/GET_STARTED/).
Before using a newer Runtime, recheck its current capabilities and revision.
The pack provides static authoring context; actual Agent execution feedback must
still validate its usefulness with the general Plan surface when that is available.
